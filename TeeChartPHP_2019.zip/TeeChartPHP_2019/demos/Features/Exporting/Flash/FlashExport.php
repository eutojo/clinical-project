<?php        
        print '<font face="Verdana" size="2">Result of the Exportation to Flash / Flex.<p>';
        
?>
<html>
<head>
<style type="text/css">
html, body
{
height: 100%;
margin: 0;
padding: 0;
}
</style>
</head>
<body>


<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
id="Chart1" width="500" height="350" menu="true"
codebase="http://fpdownload.macromedia.com/get/flashplayer/current/swflash.cab"/>
<param name="movie" value="Chart1.swf"/>
<param name="quality" value="high"/>
<param name="menu\" value="true"/>
<param name="bgcolor" value="FFFFFF"/>
<param name="allowScriptAccess" value="sameDomain"/>
<embed src="Chart1.swf" width="500" height="350"/>
</object>
</body>
</html>


